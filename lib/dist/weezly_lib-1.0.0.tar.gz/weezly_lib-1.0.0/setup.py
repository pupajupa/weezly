from setuptools import find_packages, setup

setup(
    name='weezly_lib',
    packages=find_packages(),
    version='1.0.0',
    description='My weezly_lib app lib',
    author='Maksim Antikhovitch',
    install_requires=[],
)