from dataclasses import dataclass
from .category import Category
import datetime,slugify

@dataclass
class Product:
    _id: int
    _category: Category
    _image: str
    _title: str
    _description: str
    _price: int
    _date_created: datetime.datetime = None
    _slug: str = None

    @property
    def id(self):
        return self._id
    
    @property
    def category(self):
        return self._category
    
    @property
    def image(self):
        return self._image
    
    @property
    def title(self):
        return self._title
    
    @property
    def description(self):
        return self._description
    
    @property
    def price(self):
        return self._price
    
    @property
    def date_created(self):
        return self._date_created
    
    @property
    def slug(self):
        return self._slug

    def __post_init__(self):
        self.slug = slugify(self.title)